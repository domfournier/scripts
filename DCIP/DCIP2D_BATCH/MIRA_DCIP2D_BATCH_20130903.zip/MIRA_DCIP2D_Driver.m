% MIRA - DCIP2D Batch Inversion 
% This program uses a series of sub-routines to extract data from the 
% TQIOdb output files and invert using the UBC code.
% Input arguments:
% 'all': Process all lines
% or
% '## ##' : Process only lines ## (sequential order from the top)
clear all
close all

addpath functions

%% Extract files and create directories
input_folder = 'C:\Projects\4081_Teck_HVC_DCIP3D\Data\Processing';
raw_folder = 'C:\Projects\4081_Teck_HVC_DCIP3D\Data\Processing\Raw';
edt_folder = 'C:\Projects\4081_Teck_HVC_DCIP3D\Data\Processing\Edited';
output_folder = 'C:\Projects\4081_Teck_HVC_DCIP3D\Data\Processing\MIRA_Inv2D';

% lines = 'all';
lines = [1 4 7 8 24 20 27];
lines = num2str(lines);
% Different pre-formating routines are offered here

% For Titan type
% TQIP_2_folder(input_folder,output_folder,lines);
% UBC_2_folder_FWR_BCK(input_folder,output_folder,lines);

% For output from *.gdb files in format <line, T1X, T2X, R1X, R2X, data>
% gdb_2_UBC(input_folder,raw_folder,'TECK_Data_gdb_DC.dat','TECK_Data_gdb_IP.dat')
% UBC_2_folder(edt_folder,output_folder,lines);
%% Run DC inversions
% DC_Batch_Inv(output_folder,lines);

%% Run IP inversions
IP_Batch_Inv(output_folder,lines);

%% Re-compute standard deviations from the log files
DCIP_Batch_STD(output_folder,lines);



%% Georeference data
% 1- Extract survey information (format might need to change)
% survey_full = get_survey('C:\Projects\4001_Wallbridge_SkynnerLake_DCIP\Data\from_client\Titan\Survey','all');
survey_full =load([input_folder '\4081_Survey_ALL.dat']);
Georef_data(survey_full,output_folder,lines)


%% Invert three new models for computing the Depth of Investigation
% Cond_model(1) = 3e-4;
% Cond_model(2) = 6e-4;
% Charg_model(1) = 5e-3;
% 
% DCIP_Batch_DOI(Cond_model,Charg_model,output_folder,lines);
