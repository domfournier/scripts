function [survey] = get_survey(work_directory,argin)
% Extract UTM station coordinates from survey files. 
% Read files with format:
% Line 20N,NAD83 z17T,,,,,,,,,

% Latitude,Longtitude,Northing UTM,Easting UTM,Elevation,Grid Northing,Grid Easting,Elevation,description,,
% 01,"46�43'23.85""N",""80�51'59.29""W",5174424,510204,316,5174424,510204,316,100L20N
% 02,"46�43'23.82""N",""80�51'58.07""W",5174423,510230,324,5174423,510230,324,125L20N
% ...
%
% Output:
% Y_UTM X_UTM Elevation Station Line
%  ...
%
% Author: D Fournier
% Last update : April 10th, 2013

home_dir = pwd;
fprintf('***START READING SURVEY FILES***\n')
%% CHANGE DIRECTORY HERE AND RUN >>>>>>>>>>
cd (work_directory)

%% Driver
max_num_lines=30000;

Sline_list=ls;

line_range = argin;

survey = [];
switch line_range 
    case 'all'
       range = 1:size(Sline_list,1)-2;
       
    otherwise
        range = str2num(argin);

end

    count = 0;
% Cycle through all the survey lines
for oo=range

    
    suvey_file = Sline_list(oo+2,:);
    %% Read the dc log file and extract information
    fid=fopen(suvey_file,'rt');
    
    
    % Go through the log file and extract data and the last achieved misfit

    for ii=1:max_num_lines         	
        line=fgets(fid); %gets next line 
        
        %Start looking at line 4
        if ii>3
        count=count+1;

        if line==-1
            fprintf('File ended at line %i\n',ii);
            break
        end
        
    
    %Extract data
        XYZ = line(58:76);
        survey(count,1:3)= str2num(XYZ);
        
        % Extrat station number and line number
        ID_num = line(77:end);ID_num = strrep(ID_num,'L',' ');ID_num = strrep(ID_num,'N',' ');
        survey(count,4:5) = str2num(ID_num);
        
%             if strcmp(strtrim(line),'pole-dipole')==1
                
        end      
    
    end
    
    

end

    fprintf('***END OF get_survey***\n')
cd(home_dir);    
    
    
%         test_freq_match=strcmp(line(1:length(match_freq)),match_freq);